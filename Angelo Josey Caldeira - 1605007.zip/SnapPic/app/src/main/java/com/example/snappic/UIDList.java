package com.example.snappic;
//TO RETURN THE UID
public class UIDList {
    public String uid;

    public UIDList(){

    }

    public UIDList(String uid) {
        this.uid = uid;
    }



}
