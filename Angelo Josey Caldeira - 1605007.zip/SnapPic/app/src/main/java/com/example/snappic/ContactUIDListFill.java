package com.example.snappic;

public class ContactUIDListFill {
    public String uid;

    public ContactUIDListFill(String uid){
        this.uid = uid;
    }


    public String getUID() {
        return uid;
    }


    public void setUID(String uid) {
        this.uid = uid;
    }



}
